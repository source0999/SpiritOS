import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, 
  Plus, 
  MoreVertical, 
  Send, 
  Settings, 
  Search, 
  MessageSquare, 
  Clock, 
  User, 
  ThumbsUp, 
  ThumbsDown, 
  Copy, 
  Volume2, 
  Share2,
  ChevronRight,
  Mic,
  Sparkles,
  Command,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatState, Message, ChatThread } from './types.ts';

// --- Components ---

const IconButton = ({ icon: Icon, onClick, className = "", size = 20 }: any) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-full hover:bg-white/10 transition-all active:scale-95 text-text-muted hover:text-text ${className}`}
  >
    <Icon size={size} />
  </button>
);

const SuggestionChip = ({ text, onClick }: { text: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="px-4 py-2 rounded-full border border-border bg-surface hover:bg-surface-2 transition-all active:scale-95 text-sm whitespace-nowrap"
  >
    {text}
  </button>
);

const MessageBubble = ({ message }: { message: Message }) => {
  const isUser = message.role === 'user';
  
  return (
    <div className={`flex flex-col mb-6 ${isUser ? 'items-end' : 'items-start'}`}>
      <div className={`max-w-[90%] md:max-w-[80%] rounded-2xl px-4 py-3 leading-relaxed ${
        isUser 
          ? 'bg-accent-soft text-text border border-accent/20 rounded-tr-none' 
          : 'bg-transparent text-text'
      }`}>
        {message.content.includes('```') ? (
          <div className="space-y-2">
            <p>{message.content.split('```')[0]}</p>
            <pre>
              <code>{message.content.split('```')[1]}</code>
            </pre>
            <p>{message.content.split('```')[2]}</p>
          </div>
        ) : (
          <p className="whitespace-pre-wrap">{message.content}</p>
        )}
      </div>
      
      {!isUser && (
        <div className="flex gap-1 mt-2 ml-1">
          <IconButton icon={Copy} size={14} className="p-1.5" />
          <IconButton icon={Volume2} size={14} className="p-1.5" />
          <IconButton icon={ThumbsUp} size={14} className="p-1.5" />
          <IconButton icon={Share2} size={14} className="p-1.5" />
          <IconButton icon={MoreVertical} size={14} className="p-1.5" />
        </div>
      )}
    </div>
  );
};

const Composer = ({ state, onSend }: { state: ChatState, onSend: (text: string) => void }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim()) {
      onSend(input);
      setInput('');
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  return (
    <div className={`w-full max-w-3xl mx-auto px-4 pb-4 md:pb-8`}>
      <div className="relative group">
        <div className="absolute inset-0 bg-accent/5 blur-2xl rounded-premium opacity-0 group-focus-within:opacity-100 transition-opacity" />
        <div className="relative flex flex-col glass rounded-premium p-2 pr-4 shadow-2xl transition-all border-white/10 group-focus-within:border-accent/30">
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask Spirit anything"
            className="w-full bg-transparent px-4 py-3 focus:outline-none resize-none max-h-48 text-text placeholder:text-text-muted"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          />
          <div className="flex items-center justify-between px-2 pb-1">
            <div className="flex items-center gap-1">
              <IconButton icon={Plus} />
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/5 text-[10px] uppercase tracking-wider font-semibold text-text-muted">
                <Sparkles size={12} className="text-accent" />
                <span>Peer</span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <IconButton icon={Mic} />
              <button 
                onClick={handleSend}
                disabled={!input.trim()}
                className={`p-2 rounded-full transition-all ${
                  input.trim() ? 'bg-accent text-bg scale-100' : 'bg-white/5 text-text-muted scale-90 opacity-50'
                }`}
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
      {state === ChatState.HOME && (
        <p className="text-center text-[10px] text-text-muted mt-4 uppercase tracking-[0.2em] font-medium opacity-50">
          SpiritOS / Quantum Interface
        </p>
      )}
    </div>
  );
};

// --- App Layout ---

export default function App() {
  const [chatState, setChatState] = useState<ChatState>(ChatState.HOME);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  const threads: ChatThread[] = [
    { id: '1', title: 'Refining Mobile UX', lastMessage: 'The composer is the key...', timestamp: '2h ago', active: true },
    { id: '2', title: 'Python Backend Setup', lastMessage: 'Need to configure...', timestamp: 'Yesterday' },
    { id: '3', title: 'Weekend Travel Ideas', lastMessage: 'Kyoto sounds great', timestamp: '3 days ago' },
  ];

  const suggestions = [
    "Plan a build",
    "Debug UI",
    "Summarize notes",
    "Brainstorm ideas",
    "Write a prompt"
  ];

  const handleSend = (text: string) => {
    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMsg]);
    setChatState(ChatState.ACTIVE);

    // Mock response
    setTimeout(() => {
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: text.toLowerCase().includes('ui') 
          ? "The biggest wins for your mobile UI are simplifying the navigation and ensuring the composer is the primary hook. \n\n```tsx\nexport const Layout = () => (\n  <div className=\"h-screen flex flex-col\">\n    <main className=\"flex-1 overflow-y-auto\" />\n    <Composer />\n  </div>\n)```\n\nLet me know if you want to explore the drawer transitions specifically."
          : "That's an interesting angle. I can help you structure that or research some references. What specific part should we look at first?",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMsg]);
    }, 1000);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="flex h-screen w-full bg-bg overflow-hidden relative">
      
      {/* Sidebar - Desktop Only */}
      <aside className="hidden lg:flex flex-col w-72 h-full border-r border-border bg-surface shadow-xl">
        <div className="p-6 pb-2">
          <button 
            onClick={() => setChatState(ChatState.HOME)}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all group"
          >
            <div className="flex items-center gap-3">
              <Plus size={18} className="text-accent" />
              <span className="font-medium text-sm">New Chat</span>
            </div>
            <Command size={14} className="text-text-muted opacity-30 group-hover:opacity-100" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 py-2 space-y-1">
          <h3 className="px-4 py-3 text-[10px] uppercase font-bold tracking-widest text-text-muted opacity-60">Recent Activity</h3>
          {threads.map(thread => (
            <button 
              key={thread.id}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all group relative overflow-hidden ${
                thread.active ? 'bg-accent/10 border border-accent/20' : 'hover:bg-white/5 border border-transparent'
              }`}
            >
              <div className="flex justify-between items-start mb-0.5">
                <span className={`text-sm font-medium truncate ${thread.active ? 'text-accent' : 'text-text'}`}>
                  {thread.title}
                </span>
                <span className="text-[10px] text-text-muted whitespace-nowrap ml-2 opacity-50">
                  {thread.timestamp}
                </span>
              </div>
              <p className="text-xs text-text-muted truncate opacity-60">{thread.lastMessage}</p>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-border mt-auto">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 text-text-muted hover:text-text transition-all">
            <Settings size={18} />
            <span className="text-sm">Settings</span>
          </button>
          <div className="mt-2 flex items-center gap-3 px-4 py-3">
            <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center border border-accent/30">
              <User size={16} className="text-accent" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-semibold">Britton Smith</span>
              <span className="text-[10px] text-text-muted">Pro Plan</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col h-full w-full relative">
        
        {/* Mobile App Bar */}
        <header className={`flex items-center justify-between px-4 py-3 md:px-6 md:py-4 z-20 ${
          chatState === ChatState.ACTIVE ? 'border-b border-border bg-bg/80 backdrop-blur-md' : ''
        }`}>
          <div className="flex items-center gap-4">
            <IconButton icon={Menu} className="lg:hidden" onClick={() => setDrawerOpen(true)} />
            {chatState === ChatState.HOME ? (
              <span className="font-bold text-lg tracking-tight">Spirit</span>
            ) : (
              <div className="flex flex-col">
                <span className="text-sm font-semibold truncate max-w-[150px] md:max-w-xs">Thinking...</span>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                  <span className="text-[10px] text-text-muted font-medium uppercase tracking-wider">Syncing</span>
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center gap-1 md:gap-2">
            <IconButton icon={Plus} onClick={() => {setChatState(ChatState.HOME); setMessages([]);}} />
            <div className="lg:hidden w-8 h-8 rounded-full bg-white/5 border border-white/5 overflow-hidden ml-1 flex items-center justify-center">
              <User size={16} className="text-text-muted" />
            </div>
          </div>
        </header>

        {/* Content Viewport */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto scroll-smooth pt-4"
        >
          {chatState === ChatState.HOME ? (
            <div className="max-w-2xl mx-auto px-6 pt-12 flex flex-col items-center">
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full text-left md:text-center mt-12 md:mt-24 mb-12"
              >
                <div className="flex items-center gap-2 mb-4 md:justify-center">
                  <span className="text-text-muted">Hi Britton</span>
                </div>
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-8 leading-tight">
                  What should we <br className="hidden md:block" /> 
                  <span className="text-accent underline decoration-accent/30 underline-offset-8">explore</span> today?
                </h1>
                
                <div className="flex flex-wrap gap-2 md:justify-center mt-12 overflow-x-auto pb-4 no-scrollbar">
                  {suggestions.map(s => (
                    <SuggestionChip key={s} text={s} onClick={() => handleSend(s)} />
                  ))}
                </div>
              </motion.div>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto px-6 py-6 pb-24">
              {messages.map(msg => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
            </div>
          )}
        </div>

        {/* Bottom Composer Area */}
        <div className="bg-gradient-to-t from-bg via-bg/95 to-transparent pt-8 z-10 px-4 md:px-0">
          <Composer state={chatState} onSend={handleSend} />
        </div>
      </main>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawerOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="lg:hidden fixed left-0 top-0 h-full w-[85%] max-w-sm bg-surface z-50 flex flex-col shadow-2xl border-r border-border"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-8">
                  <span className="font-bold text-xl tracking-tight">SpiritOS</span>
                  <IconButton icon={X} onClick={() => setDrawerOpen(false)} />
                </div>
                
                <div className="relative mb-6">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={16} />
                  <input 
                    type="text" 
                    placeholder="Search chats"
                    className="w-full bg-white/5 border border-white/5 rounded-full pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-accent/30"
                  />
                </div>

                <button 
                  onClick={() => { setChatState(ChatState.HOME); setDrawerOpen(false); setMessages([]); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-accent text-bg font-semibold text-sm mb-8 shadow-lg shadow-accent/10 transition-all active:scale-95"
                >
                  <Plus size={18} />
                  <span>New Chat</span>
                </button>

                <div className="space-y-1">
                  <h3 className="px-2 mb-2 text-[10px] uppercase font-bold tracking-[0.2em] text-text-muted opacity-50">Recent History</h3>
                  {threads.map(thread => (
                    <button 
                      key={thread.id}
                      onClick={() => { setChatState(ChatState.ACTIVE); setDrawerOpen(false); }}
                      className={`w-full text-left px-4 py-4 rounded-2xl transition-all border ${
                        thread.active ? 'bg-accent/10 border-accent/20' : 'hover:bg-white/5 border-transparent'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-0.5">
                        <span className={`text-sm font-semibold truncate ${thread.active ? 'text-accent' : 'text-text'}`}>
                          {thread.title}
                        </span>
                        <span className="text-[10px] text-text-muted ml-2 opacity-50 font-medium">
                          {thread.timestamp}
                        </span>
                      </div>
                      <p className="text-xs text-text-muted truncate opacity-60 leading-relaxed">{thread.lastMessage}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-auto p-6 border-t border-border bg-black/20">
                <div className="flex items-center gap-4 mb-2">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center border border-accent/30">
                    <User size={18} className="text-accent" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold">Britton Smith</span>
                    <span className="text-xs text-text-muted font-medium">Pro Interface Active</span>
                  </div>
                </div>
                <button className="w-full flex items-center gap-3 py-3 text-text-muted text-sm font-medium hover:text-text transition-all mt-2">
                  <Settings size={18} />
                  <span>Interface Settings</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Recommended Strategy Notes (Floating Overlay for Demo) */}
      <div className="hidden xl:block fixed bottom-8 right-8 z-[100]">
        <div className="glass p-6 rounded-2xl max-w-sm border border-accent/20 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-2 bg-accent/20 rounded-bl-xl text-[10px] text-accent font-mono uppercase font-bold">
            Spec 1.0
          </div>
          <h4 className="text-accent font-bold text-sm mb-3 flex items-center gap-2">
            <Sparkles size={16} />
            Implementation Strategy
          </h4>
          <ul className="text-xs text-text-muted space-y-3 leading-relaxed">
            <li>
              <strong className="text-text">Scroll Logic:</strong> Use <code>overflow-y-auto</code> on the message container only. Keep body locked to prevent viewport bouncing on mobile.
            </li>
            <li>
              <strong className="text-text">Safe Areas:</strong> Use <code>env(safe-area-inset-bottom)</code> for the composer to account for the Home Indicator.
            </li>
            <li>
              <strong className="text-text">Bottom Nav:</strong> REMOVE. For chat apps, the composer + side drawer (Gemini pattern) is superior UX vs. a fixed bottom bar that clashes with the keyboard.
            </li>
            <li>
              <strong className="text-text">Tailwind Port:</strong> All tokens are mapped to CSS variables. Copy the <code>@theme</code> block to your Next.js project.
            </li>
          </ul>
        </div>
      </div>

    </div>
  );
}

