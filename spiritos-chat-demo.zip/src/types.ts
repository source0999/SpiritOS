export enum ChatState {
  HOME = 'home',
  ACTIVE = 'active'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface ChatThread {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: string;
  active?: boolean;
}
